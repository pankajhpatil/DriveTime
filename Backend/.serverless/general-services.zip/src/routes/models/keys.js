module.exports = {
    MongoURI: 'mongodb+srv://manishDb:ty2TOCRijaDwJhUY@emaily-2r7gc.mongodb.net/test?retryWrites=true&w=majority'
};