
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'manishhanmantraolokhande',
  applicationName: 'general-services-app',
  appUid: 'QQsF8bQn9q5kVwwg9y',
  orgUid: 'hRLkT1Q61hK3Hxb65f',
  deploymentUid: '8e149c4e-853a-4c87-9fc4-a89801eecb7e',
  serviceName: 'general-services',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.11',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'general-services-dev-api', timeout: 6 };

try {
  const userHandler = require('./lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.universal, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}